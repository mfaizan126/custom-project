var config = {
    map: {
        '*': {
            custom:'js/custom'
        }
    },

    deps: [
        "custom"
    ],

};
